<div id="wacht">
<a href="https://wa.me/6281362117384?text=Hello%20Mr.Vincent!%20Iam%20interested%20to%20booking%20your%20room%20at%20Hotel%20..">WhatsApp</a>
</div>