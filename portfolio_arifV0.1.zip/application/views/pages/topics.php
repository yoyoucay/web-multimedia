<div class="container-fluid my-5 py-3">
<h1 class="heading1 text-left" style="padding: 45px;">Topiks Multimedia</h1>
    <div class="bg-light" style="padding: 45px">
        <h3 class="heading1 text-left bg-light" style="padding: 15px;">Desain Grafis</h6>
        <p style="padding: 20px">Desain grafis merupakan bentuk komunikasi visual menggunakan gambar digital untuk
            menyampaikan informasi yang menarik dan atau menyenangkan.</p>       
        <ol>Teknik Manipulasi Citra</ol>
        <nav class="navbar navbar-expand-lg navbar-light bg-light"> 
        <ul class="list-group">
            <li> Teknik Kolase </li>
            <picture class="img-center">
            <img src="<?php echo base_url('assets/img/Karya1.jpg');?>" style="padding: 35px;" class="img-fluid" alt="Responsive image">
            </picture>
            <li> Teknik Duplicate Layer </li>
            <picture class="img-center">
                <img src="<?php echo base_url('assets/img/Karya2.jpg');?>" style="padding: 35px;" class="img-fluid" alt="Responsive image">
            </picture>
        </ul>
        </nav> 
    </div>
    <hr>
    <div class="bg-light" style="padding: 45px">        
        <h4 class="heading1 text-left bg-light" style="padding: 45px;">Animasi</h6>
        <nav class="navbar navbar-expand-lg navbar-light bg-light"> 
        <ul class="list-group">
            <li> Contoh Motion Graphic </li>
            <video class="mt-2 rounded" style="width: 800px; margin: 30px; padding: 30px;" controls>
                <source src="<?php echo base_url('assets/vids/hmm.mp4');?>" type="video/mp4">
            </video>
            <li> Motion Graphic - User Guide </li>
            <picture class="img-center" style="padding: 20px; margin: 20px;">
            <iframe src="//www.slideshare.net/slideshow/embed_code/key/BRv8EPJ4W8LvUh" width="800" height="600" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%;" allowfullscreen> </iframe> 
            </picture>
        </ul>
        </nav> 
    </div>
    <hr>

    
</div>

<style>
hr {
  height: 4px;
  margin-left: 15px;
  margin-bottom:-3px;
}
.hr-warning{
  background-image: -webkit-linear-gradient(left, rgba(210,105,30,.8), rgba(210,105,30,.6), rgba(0,0,0,0));
}
.hr-success{
  background-image: -webkit-linear-gradient(left, rgba(15,157,88,.8), rgba(15, 157, 88,.6), rgba(0,0,0,0));
}
.hr-primary{
  background-image: -webkit-linear-gradient(left, rgba(66,133,244,.8), rgba(66, 133, 244,.6), rgba(0,0,0,0));
}
.hr-danger{
  background-image: -webkit-linear-gradient(left, rgba(244,67,54,.8), rgba(244,67,54,.6), rgba(0,0,0,0));
}
</style>