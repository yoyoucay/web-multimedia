<div class="container-fluid my-5 py-3">
    <!-- <div style="padding: 45px;"> -->
        <h1 class="heading1 text-left" style="padding: 45px;">Tentang</h1>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- <h1>Blockquotes</h1> -->
        <!-- <p>The blockquote element is used to present content from another source:</p> -->
        <blockquote>
            <p>
                Halo semuanya! Saya Arif Febriana, lahir di Indramayu pada 17 Februari 1999. Saya sekarang tinggal di Batam, Kepulauan Riau - Indonesia. Pekerjaan saya sekarang adalah sebagai Mahasiswa di Politeknik Negeri Batam Angkatan Tahun 2017.
                Hobi saya adalah bermain Game, saya memainkan banyak jenis game, salah satunya adalah Adventure, Strategy, Mystery dan masih banyak lagi.
            </p>

            <p>
            Selain bermain Game, saya sering melakukan aktivitas seperti bisa dibilang "Programmer", yang tapi bagi saya skill saya untuk sekarang ini belum bisa di sebut sebagai "Programmer",
                bahasa pemograman yang pernah saya pelajari antara lain adalah PHP, Javascript, Java, C, C#, SQL, Visual Basic, Python dan lain-lain.
            </p>
        </blockquote>
    </nav>
    <!-- </div> --> 
</div>
