<div class="container-fluid my-5 py-3">

    <div style="padding: 45px;">
        <h1 class="heading1 text-left">Kontak</h1>
    </div>
    

</div>
