<div class="container-fluid my-5 py-3">

    <header class="masthead">
    <div class=" h-100">
        <div class="row h-100 align-items-center">
        <div class="col-12 text-left" style="padding: 45px;">
            <h1 class="font-weight-light">Hello! Iam Arif Febriana</h1>
            <p class="lead">A just normal hooman, but like to play games, </p>
            <p class="lead">simple people, nothing special. </p>
        </div>
        </div>
    </div>
    </header>

</div>

<style>
.masthead {
  height: 100vh;
  min-height: 500px;
  background-image: url('https://images3.alphacoders.com/658/658828.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}
</style>