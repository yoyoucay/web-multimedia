<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Halaman extends CI_Controller {
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function home()
	{
		$this->load->view('layouts/header');
		$this->load->view('etc/whatsapp.php');
		$this->load->view('pages/home.php');
		$this->load->view('pages/about.php');
		$this->load->view('pages/topics.php');
		$this->load->view('pages/contacts.php');
		$this->load->view('layouts/footer');
	}

	public function about()
	{
		$this->load->view('layouts/header');
		$this->load->view('etc/whatsapp.php');
		$this->load->view('pages/about.php');
		$this->load->view('layouts/footer');
	}

	public function topics()
	{
		$this->load->view('layouts/header');
		$this->load->view('pages/topics.php');
		$this->load->view('layouts/footer');
	}

	public function contacts()
	{
		$this->load->view('layouts/header');
		$this->load->view('pages/contacts.php');
		$this->load->view('layouts/footer');
	}

}