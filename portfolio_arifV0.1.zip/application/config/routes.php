<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'halaman/home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['home'] = 'halaman/home';
$route['facilities'] = 'halaman/facilities';
$route['gallery'] = 'halaman/gallery';
$route['room'] = 'halaman/room';

